const regras_add = (prefix, namebot) => {
	return `

REGRAS PARA ADICIONAR O ${namebot} EM SEU GRUPO

     O GRUPO QUE SOLICITAR A PRESENÇA DO BOT ${namebot}, DEVERA SEGUIR DE ACORDO COM SUAS DIRETRIZES, DO  CONTRÁRIO O BOT NÃO FICARÁ

SENDO DIRETRIZES DO BOT

 ◆➤ ⚠️ 1 CRIAR INTERAÇÃO ENTRE OS USUÁRIOS ATRAVÉS DO LEVEL

 ◆➤ ⚠️ 2 SEM FLOOD OU E BAN

 ◆➤ ⚠️ 3 TER RESPEITO E SER RESPEITADO
 
 Requisitos para manter  bot no seu grupo
 
 ◆➤ ⚠️ 1 Acesse *_https://sites.google.com/view/albion-desenvolvedor/registra-grupo_*
 
 *Registre o grupo!* ou baixe nosso app [ ~ANDROID~ ] em: _*https://sites.google.com/view/albion-desenvolvedor/download/app*_
 
 
 ◆➤ ⚠️ 2  *SER MAIOR QUE NÍVEL 3 [ Não é nescesario se você registrar o grupo ou acessa e registrar pelo app ]*
  
 ◆➤ ⚠️ 3 *DEVERÁ ESTÁ É PERMANECE NO GRUPO DE CONTROLE (Digite ${prefix}gpof )*
 

 ◆➤ SE VOCÊ FOR OU FAZER PARTE DA ORGANIZAÇÃO DE
BONDES/PROJETO DIGITE:  ${prefix}regras_bonde
`
}

exports.regras_add = regras_add
