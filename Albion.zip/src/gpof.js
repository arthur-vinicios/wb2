const gpof = (prefix) => {
	return `
Grupos Oficiais

*Grupo 0:* https://chat.whatsapp.com/FfApACg0KpcB5p9QZS2cB4
 
*Central 1:* https://chat.whatsapp.com/Ee1CGZJJmyl466XLt3tFTb

*Central 2:* https://chat.whatsapp.com/CSjnLxXdNDS7IAoNIOMSWx

*Central 3:* https://chat.whatsapp.com/EiB7cIaC6b8Dnz1BCRsF71

`
}

exports.gpof = gpof
