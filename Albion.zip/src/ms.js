const ms = (nameuser,namebot ) => {


if (nameuser === "Desconhecido.") {nameuser = sender.split('@')[0]}
        return `
        Whatsapp

https://chat.whatsapp.com/FfApACg0KpcB5p9QZS2cB4

Facebook

https://www.facebook.com/albion.desenvolvedor.5

Twitch

https://www.twitch.tv/albion_desenvolvedor

Instagram

http://www.instagram.com/albion_desenvolvedor

Discord

https://discord.gg/yCpfKYnTbh

Twitter

https://twitter.com/AlbionDesen

YouTube

https://www.youtube.com/channel/UCXJ3ycYgqx47X9lWGfgetEg

Telegram

https://t.me/albion_desenvolvedor
  `
}

exports.ms = ms
