const nsfwmenu = (prefix, pushname) => {
    return `༺《 🔞 ᴀʟʙɪᴏɴ ʙᴏᴛ 🔞 》༻

          😈 ᴍᴇɴᴜ ɴsғᴡ 😈

╔────────────────     
║➪ ⚠︎ ⸢ ${prefix}ɴsғᴡʙᴏʙs ⸥         |0xᴘ|
║➪ ⚠︎ ⸢ ${prefix}ʀᴀɴᴅᴏᴍɢᴇɴᴛᴀɪᴏ ⸥  |0xᴘ|
║➪ ⚠︎⸢ ${prefix}ɴsғᴡsɪᴅᴇʙᴏʙs ⸥    |0xᴘ|
║➪ ⚠︎⸢ ${prefix}ɴsғᴡᴀʜᴇɢᴀᴏ ⸥   |0xᴘ|
║➪ ⚠︎ ⸢ ${prefix}ɴsғᴡᴛʜɪɢʜs ⸥    |0xᴘ|
║➪ ⚠︎ ⸢ ${prefix}ɴsғᴡᴀʀᴍᴘɪᴛs ⸥  |0xᴘ|
║➪ ⚠︎ ⸢ ${prefix}ʜᴇɴᴛᴀɪ ⸥  |0xᴘ|
║➪ ⚠︎ ⸢ ${prefix}porn ⸥ |0xᴘ|  
║➪ ⚠︎ ⸢ ${prefix}pornlesbian ⸥  |0xᴘ|
║➪ ⚠︎ ⸢ ${prefix}porngay ⸥  |0xᴘ|
╚────────────────
ᴛᴏᴅᴏs ᴏs ᴄᴏᴍᴀɴᴅᴏs ᴀᴄɪᴍᴀ ɴᴇᴄᴇssɪᴛᴀᴍ ǫᴜᴇ ᴏ ɴsғᴡ ᴇsᴛᴇᴊᴀ ᴀᴛɪᴠᴏ

 ᴅɪɢɪᴛᴇ ${prefix}ᴍᴇɴᴜ  ᴘᴀʀᴀ ᴏʙᴛᴇʀ ᴍᴀɪs ᴄᴏᴍᴀɴᴅᴏs
                                                              
  `



}

exports.nsfwmenu = nsfwmenu
