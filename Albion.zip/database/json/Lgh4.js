const fs = require("fs")
const { exec } = require('child_process')

try{
global.users = JSON.parse(fs.readFileSync('./users.json'))
global.level = JSON.parse(fs.readFileSync('./level.json'))
}catch (e){
n = e.path
//console.log(`${n.split("./")[1]}`)
if (String(e).includes(".json") || String(e).includes("ENOENT:")){
nome = `${n.split("./")[1]}`
console.log(`error detectado ${nome}`)
if (nome === 'YouProfile.json'){
exec(`cd database/json/ ; echo {'"Botname"':'"Albion"','"Prefix"':'"!"','"AlbionID"':'"0000AAAA"','"Owner"':'"5516999469735@s.whatsapp.net"','"face"':'"ok"','"insta"':'"lsksks"'}>>${nome}`)
process.exit(0)
}
exec(`cd database/json/ ; echo []>>${nome}`)
process.exit(0)
}
else {
console.log(e)
}}
qtd = 0
Object.keys(level).forEach((i) => {

numero = level[i].jid
xp = level[i].xp
levell = level[i].level
Object.keys(users).forEach((n) => {
u = n
//console.log(qtd)
if(users[u].numero == numero.split("@")[0] && users[u].at != 0){
qtd =+  qtd + 1
users[u].at = 1
users[u].xp = xp
users[u].level = levell
users[u].idU = u
users[u].jid = numero
fs.writeFileSync('./users.json', JSON.stringify(users))

}})
})
 
exec('cls')
console.log(`\n  Olá encontramos ${users.length} usuários e ${level.length} level registrado.\n\n  Porém Conseguimos Atualizar ${qtd} e ficou ${users.length - qtd} pessoas sem Atualizar.\n\n  Veja que o proprio bot vai criar sozinho depois.\n`)
