def nome(nome):
    import os
    print(os.name)
    print(nome)
def main(a,b,c):
    n = (a ** b) * 5000
    b = n - c
    return b
nome(nome)
