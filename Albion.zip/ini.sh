NKM=0
while :
do
NKM=$(($NKM+1))
rm -rf *.ogg 
rm -rf *.mp3
rm -rf *.mp4 
rm -rf *.webp
clear
setterm -foreground yellow
echo SYSTEM INI VERSÃO 1.2
setterm -foreground default
echo 
echo 
echo 
setterm -foreground red
echo  ........................................
echo
setterm -foreground default
echo   "Reiniciando pela  $NKM VEZ"
echo    
echo   
echo       "Albion Desenvolvedor"
setterm -foreground red
echo  ........................................
setterm -foreground default
echo 
echo
echo
echo
echo
echo
echo

node index.js

done
