const menuadmin = (prefix, pushname) => {
 return `oiin aqui e o menu dos admins
*_obs para o bot executar esses comandos e nescessario dar adm para o bot_* 

  *COMANDO DOS ADMINS*
 │
 🔰 ${prefix}opengp
 🔰 ${prefix}closegp
 🔰 ${prefix}promote
 🔰 ${prefix}demote
 🔰 ${prefix}tagall
 🔰 ${prefix}tagall2
 🔰 ${prefix}tagall3
 🔰 ${prefix}tagall4
 🔰 ${prefix}tagall5
 🔰 ${prefix}add
 🔰 ${prefix}albioban
 🔰 ${prefix}listadmins
 🔰 ${prefix}linkgroup
 🔰 ${prefix}leave (tchau, comando usando quamdo o Dono do grupo não que o bot no grupo. sé o bot sair, não voltará )
 🔰 ${prefix}welcome (não e possivel desativar depois de ativado)
 🔰 ${prefix}nsfw
 🔰 ${prefix}leveling
 🔰 ${prefix}level (leveling deve tar ativo)
 🔰 ${prefix}delete ou ${prefix}del
 🔰 ${prefix}simih
 🔰 ${prefix}ownergroup
 `


}

exports.menuadmin = menuadmin
