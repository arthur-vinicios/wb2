const help = (prefix) => {
	return `
▂▄▅▆▇█*𝗻𝗶𝗻𝗲𝗺 𝗕𝗢𝗧*█▇▆▅▄▂ 
◆ *𝗶𝗻𝗳𝗼𝗿𝗺𝗮𝗰̧𝗼̃𝗲𝘀*
  ◆➤🔰 𝗣𝗿𝗲𝗳𝗶𝘅🔰: ◆◆  ${prefix}  ◆◆
  ◆➤ 𝗖𝗿𝗶𝗮𝗱𝗼𝗿🔰 ◆◆: NABUTO E BIRIDIN 🔰 ◆◆
░███████████░░░░
🏿🏿🏿🏿🏿🏿🏿🏿
🏿🏿🏿🏿🏿🏿🏿🏿
🏿🏿🏽🏽🏽🏽🏿🏿
🏽🏽🏽🏽🏽🏽🏽🏽
🏽⬜⬛🏽🏽⬛⬜🏽
🏽🏽🏽🏿🏿🏽🏽🏽
🏽🏽🏿🏽🏽🏿🏽🏽
🏽🏽🏿🏿🏿🏿🏽🏽
 🔰 𝐀𝐋𝐆𝐔𝐍𝐒 𝐂𝐎𝐌𝐀𝐍𝐃𝐎𝐒 𝐍𝐀̃𝐎 𝐄𝐒𝐓𝐀̃𝐎 𝐅𝐔𝐍𝐂𝐈𝐎𝐍𝐀𝐍𝐃𝐎, 𝐒𝐄 𝐕𝐈𝐌 𝐑𝐄𝐂𝐋𝐀𝐌𝐀𝐑 𝐄́ 𝐒𝐈𝐌𝐏𝐋𝐄𝐒 "𝐏𝐀𝐑𝐄 𝐃𝐄 𝐔𝐒𝐀𝐑" 𝐠𝐫𝐚𝐭𝐨.🔰
🔰𝑪𝒂𝒏𝒂𝒍 𝒅𝒐 𝒄𝒓𝒊𝒂𝒅𝒐𝒓: https://youtube.com/channel/UCZEtf9AlsC2zsJQwrfW-44w
𝑫𝑰𝑮𝑰𝑻𝑬 ${prefix}𝒊𝒏𝒇𝒐 𝑷𝑨𝑹𝑨 𝑴𝑨𝑰𝑺 𝑰𝑵𝑭𝑶𝑹𝑴𝑨𝑪̧𝑶̃𝑬𝑺
    🔰❦❧❦❧❦❧ - ❦❧❦❧❦❦❧❦🔰
◆ 𝐂𝐑𝐈𝐀𝐑 𝐋𝐈𝐍𝐊 𝐏𝐀𝐑𝐀 𝐒𝐄𝐔 𝐖𝐏𝐏
 ◆◆➤${prefix}𝐰𝐚.𝐦𝐞
 ◆◆➤${prefix}wame
◆ *𝐒𝐎𝐁𝐑𝐄*

 ◆➤ $${prefix}owner
      (Dono)
 
 ◆➤ ${prefix}𝐢𝐧𝐟𝐨𝐧𝐨𝐦𝐨𝐫
 ◆➤ ${prefix}𝐛𝐥𝐨𝐜𝐤𝐥𝐢𝐬𝐭
     (lista de contatos bloqueados)
 ◆➤ ${prefix}𝐜𝐡𝐚𝐭𝐥𝐢𝐬𝐭
     (lista de chat)
 ◆➤ ${prefix}𝐩𝐢𝐧𝐠
     (cell)
 ◆➤ ${prefix}𝐛𝐮𝐠𝐫𝐞𝐩𝐨𝐫𝐭
     (bug report)
 ◆◆➤${prefix}𝐦𝐚𝐤𝐞𝐫𝐦𝐞𝐧𝐮
◆➤ *𝑪𝑶𝑴𝑨𝑵𝑫𝑶 2*
  
 ◆➤ ${prefix}𝐬𝐭𝐢𝐜𝐤𝐞𝐫
     (fazer sticker)
 ◆➤ ${prefix}𝐬𝐭𝐢𝐜𝐤𝐞𝐫𝐠𝐢𝐟
     (msm coisa doque o de cima)
 
◆➤ ${prefix}𝐜𝐨𝐯𝐢𝐝𝐜𝐨𝐮𝐧𝐭𝐫𝐲
     (info covid)
◆➤ ${prefix}𝐭𝐨𝐢𝐦𝐠
   (converte figurinha em imagem)
 ◆➤ ${prefix}𝐭𝐨𝐦𝐩3
     (baixar áudio de jm vídeo do *wpp* )
 
 ◆➤ ${prefix}𝐭𝐭𝐩
 ◆➤ ${prefix}𝐬𝐡𝐨𝐭𝐚
 ◆➤ ${prefix}𝐪𝐮𝐨𝐭𝐞𝐦𝐚𝐤𝐞𝐫
 ◆➤ ${prefix}𝐭𝐞𝐬𝐭𝐢𝐧𝐞
 ◆➤ ${prefix}𝐬𝐞𝐦𝐨𝐣𝐢
 
 ◆➤ ${prefix}𝐚𝐧𝐢𝐦𝐞𝐜𝐫𝐲
 ◆➤ ${prefix}𝐛𝐮𝐠𝐫𝐞𝐩𝐨𝐫𝐭
      (reporta bug)
 ◆ 𝐆𝐑𝐔𝐏𝐎𝐒
 ◆➤ ${prefix}𝐨𝐰𝐧𝐞𝐫𝐠𝐫𝐨𝐮𝐩
      (dono do grupo)
 ◆➤ ${prefix}𝐥𝐢𝐧𝐤𝐠𝐫𝐨𝐮𝐩 𝐨𝐮 𝐥𝐢𝐧𝐤𝐠𝐜
      (link do grupo)
 ◆➤ ${prefix}𝐜𝐥𝐨𝐬𝐞𝐠𝐜
      (fechar grupo)
 ◆➤ ${prefix}𝐨𝐩𝐞𝐧𝐠𝐜
 ◆➤ ${prefix}𝐤𝐢𝐜𝐤 @
     (banir membro)
 ◆➤ ${prefix}𝐩𝐫𝐨𝐦𝐨𝐭𝐞 @
      (dá adm)
 ◆➤ ${prefix}𝐝𝐞𝐦𝐨𝐭𝐞 @
     (revaixar ADM)
  
 ◆+𝟭𝟴 HENTAI
 ◆➤ ${prefix}𝐫𝐚𝐧𝐝𝐨𝐦𝐡𝐞𝐧𝐭𝐚𝐢
 ◆➤ ${prefix}𝐡𝐞𝐧𝐭𝐚𝐢
      (hentai né pae)😍
 ◆➤ ${prefix}𝐫𝐚𝐧𝐝𝐨𝐦𝐡𝐞𝐧𝐭𝐚𝐢𝐨
◆ *𝐌𝐈́𝐃𝐈𝐀*
  
 ◆➤ ${prefix}𝐭𝐫𝐞𝐧𝐝𝐭𝐰𝐢𝐭
 ◆➤ ${prefix}𝐫𝐚𝐧𝐝𝐨𝐦𝐤
 ◆➤ ${prefix}𝐲𝐭𝐬𝐞𝐚𝐫𝐜𝐡
◆ *𝑪𝑶𝑴𝑨𝑵𝑫𝑶𝑺 3*
  
 ◆➤ ${prefix}𝐰𝐢𝐤𝐢
 ◆➤ ${prefix}𝐰𝐢𝐤𝐢𝐞𝐧
 ◆➤ ${prefix}𝐧𝐮𝐥𝐢𝐬
 ◆➤ ${prefix}𝐪𝐮𝐨𝐭𝐞𝐬
 ◆➤ ${prefix}𝐪𝐮𝐨𝐭𝐞𝐬2
 ◆➤ ${prefix}𝐚𝐫𝐭𝐢𝐧𝐚𝐦𝐚
◆ *MAGIC SHELL*
  
 ◆➤ ${prefix}𝐚𝐩𝐚𝐤𝐚𝐡
 ◆➤ ${prefix}𝐤𝐚𝐩𝐚𝐧𝐤𝐚𝐡
 ◆➤ ${prefix}𝐫𝐚𝐭𝐞
 ◆➤ ${prefix}𝐛𝐢𝐬𝐚𝐤𝐚𝐡
◆ *𝑫𝑶𝑾𝑵𝑳𝑶𝑨𝑫𝑺*
  
 ◆➤ ${prefix}𝐢𝐦𝐚𝐠𝐞𝐬
 ◆➤ ${prefix}𝐲𝐭𝐦𝐩3
 ◆➤ ${prefix}𝐲𝐭𝐦𝐩4
 ◆➤ ${prefix}𝐭𝐢𝐤𝐭𝐨𝐤
 ◆➤ ${prefix}𝐣𝐨𝐨𝐱
◆ *𝒎𝒆𝒎𝒆*
  
 ◆➤ ${prefix}𝐦𝐞𝐦𝐞
 ◆➤ ${prefix}𝐦𝐞𝐦𝐞𝐢𝐧𝐝𝐨
◆ *𝐒𝐎𝐌*
  
 ◆➤ ${prefix}𝐩𝐥𝐚𝐲
 ◆➤ ${prefix}𝒃𝒂𝒊𝒙𝒂𝒓
 ◆➤ ${prefix}}𝐭𝐭𝐬
◆ *𝐌𝐔́𝐒𝐈𝐂𝐀*
  
 ◆➤ ${prefix}𝐥𝐢𝐫𝐢𝐤
 ◆➤ ${prefix}𝐜𝐡𝐨𝐫𝐝
◆ *𝐈𝐒𝐋𝐀𝐌*
  
 ◆➤ ${prefix}𝐪𝐮𝐫𝐚𝐧
◆ *𝐒𝐓𝐀𝐋𝐊*
  
 ◆➤ ${prefix}𝐭𝐢𝐤𝐭𝐨𝐤𝐬𝐭𝐚𝐥𝐤
 ◆➤ ${prefix}𝐢𝐠𝐬𝐭𝐚𝐥𝐤
◆ *W𝐈𝐁𝐔*
  
  ◆ 𝑨𝑵𝑰𝑴𝑬𝑺
 ◆➤ ${prefix}𝐚𝐧𝐢𝐦𝐞𝐡𝐮𝐠
 ◆➤ ${prefix}𝐧𝐞𝐨𝐧𝐢𝐦𝐞
      (anime)
 ◆➤ ${prefix}𝐩𝐨𝐤𝐞𝐦𝐨𝐧
     (foto pokémon)
 ◆➤ ${prefix}𝐥𝐨𝐥𝐢
     (foto loli)
 ◆➤ ${prefix}}𝐰𝐚𝐢𝐟𝐮
      (waifu)
 ◆➤ ${prefix}𝐫𝐚𝐧𝐝𝐨𝐦𝐚𝐧𝐢𝐦𝐞
      (foto anime)
 ◆➤ ${prefix}}𝐡𝐮𝐬𝐛𝐮
      (sla)
 ◆➤ ${prefix}𝐡𝐮𝐬𝐛𝐮2
      (sla)
 ◆➤ ${prefix}}𝐰𝐚𝐢𝐭
      (pesquisar anime)
 ◆➤ ${prefix}𝐧𝐞𝐤𝐨𝐧𝐢𝐦𝐞
      (nekoanime)
◆ *𝐃𝐈𝐕𝐄𝐑𝐒𝐀̃𝐎*
  │
 ◆➤ ${prefix}𝐚𝐥𝐚𝐲
 ◆➤ ${prefix}𝐠𝐚𝐧𝐭𝐞𝐧𝐠𝐜𝐞𝐤
 ◆➤ ${prefix}𝐰𝐚𝐭𝐚𝐤
 ◆➤${prefix}𝐡𝐨𝐛𝐛𝐲
 ◆➤ ${prefix}𝐠𝐚𝐦e. *a maioria*       
   c             *não fuciona*
 ◆➤ ${prefix}𝐭𝐫𝐮𝐬𝐭
 ◆➤ ${prefix}𝐝𝐚𝐫𝐞
 ◆➤ ${prefix}𝐬𝐢𝐦𝐢
◆ *𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐂̧𝐀̃𝐎*
  
 ◆➤ ${prefix}𝐛𝐚𝐡𝐚𝐬𝐚
 ◆➤ ${prefix}𝐤𝐨𝐝𝐞𝐧𝐞𝐠𝐚𝐫𝐚
 ◆➤ ${prefix}𝐤𝐛𝐛𝐢
 ◆➤ ${prefix}𝐟𝐚𝐤𝐭𝐚
 ◆➤ ${prefix}𝐢𝐧𝐟𝐨𝐜𝐮𝐚𝐜𝐚
 ◆➤ ${prefix}𝐢𝐧𝐟𝐨𝐠𝐞𝐦𝐩𝐚
 ◆➤ ${prefix}𝐣𝐚𝐝𝐰𝐚𝐥𝐭𝐯𝐧𝐨𝐰
 ◆➤ ${prefix}𝐜𝐨𝐯𝐢𝐝
◆ *𝑷𝑹𝑶𝑷𝑹𝑰𝑬𝑻𝑨́𝑹𝑰𝑶*
  
 ◆➤ ${prefix}𝐬𝐞𝐭𝐩𝐫𝐞𝐟𝐢𝐱
      (𝒎𝒖𝒅𝒂𝒓 𝒐 𝒔𝒆𝒕𝒑𝒓𝒆𝒇𝒊𝒙)
 ◆➤ ${prefix}𝐛𝐥𝐨𝐜𝐤
      (𝒃𝒍𝒐𝒒𝒖𝒆𝒂𝒓)
 ◆➤  ${prefix}𝐛𝐜
      (𝒕𝒓𝒂𝒏𝒔𝒎𝒊𝒔𝒔𝒂̃𝒐)
 ◆➤ ${prefix}𝐛𝐜𝐠𝐜
      (𝒕𝒓𝒂𝒏𝒔𝒎𝒊𝒔𝒔𝒂̃𝒐 𝒔𝒐́ 𝒏𝒐 𝒈𝒑)
 ◆➤ ${prefix}𝐜𝐥𝐨𝐧𝐞
      (𝒑𝒆𝒈𝒂𝒓 𝒑𝒆𝒓𝒇𝒊𝒍)
 ◆➤ ${prefix}𝐜𝐥𝐞𝐚𝐫𝐚𝐥𝐥
      (𝒂𝒑𝒂𝒈𝒂𝒓 𝒕𝒐𝒅𝒂𝒔 𝒎𝒔𝒈)
◆ *𝐎𝐔𝐓𝐑𝐎𝐒*
   
  ◆➤ ${prefix}𝐫𝐚𝐧𝐝𝐨𝐦𝐤𝐩𝐨𝐩
  ◆➤ ${prefix}𝐬𝐞𝐧𝐝
  ◆➤ ${prefix}𝐯𝐢𝐫𝐭𝐞𝐱
       (trava)
  ◆➤ ${prefix}𝐞𝐱𝐞
  ◆➤ ${prefix}𝐪𝐫𝐜𝐨𝐝𝐞
  ◆➤ ${prefix}𝐚𝐟𝐤
  ◆➤ ${prefix}𝐭𝐢𝐦𝐞𝐫
  ◆➤ ${prefix}𝐟𝐦𝐥
  ◆➤ ${prefix}𝐟𝐦𝐥2
╭╭╮╭╭╮┈┈
             ┃┃┃┃┃┃☆┈
FIM.
             ┃┃┃┃┃┃┈┈
             ┃┛┻┛┛┃╭╮
             ┃┈┈╱▔┃┃┃
             ┃┈╱┈┈┗╯┃
             ╰┳┊┊┳━━╯
             ┏┻━━┻┓┈☆
             ┃┈┈┈┈┃┈┈
             ┃┈┈┈┈┃┈┈
`
}

exports.help = help
