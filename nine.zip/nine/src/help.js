const help = (prefix) => {
	return `
▂▄▅▆▇█ *Albion BOT* █▇▆▅▄▂ 

  ◆ *informações*

  ◆➤ 🔰𝗣𝗿𝗲𝗳𝗶𝘅🔰: ◆◆  ${prefix}  ◆◆
  
  ◆➤ Editor Chef 🔰 ◆◆: Albion 🔰 ◆◆
  
  ◆➤ 🔰 Deseja add o bot em seu grupo ? digite ${prefix}regras_add 🔰

 🔰 Alguns comando não  estão funcionado, correção aos domingos🔰
 
 🔰 Grupo oficial do bot: *https://chat.whatsapp.com/Faya6RMm7tS2nMfhtWsEDR* seja bem vindo (a)
 
 🔰 Canal do editor do bot: *https://www.youtube.com/channel/UCXJ3ycYgqx47X9lWGfgetEg* (escreva-se)
 
 🔰 site para assistir filmes: _https://sites.google.com/view/filmes-test_

◆ Cria link para seu WhatsApp

 ◆◆➤${prefix}wa.me
 
 ◆◆➤${prefix}wame
 
◆ *SOBRE*

 ◆➤ ${prefix}owner
      (Editor)
      
 ◆➤ ${prefix}blocklist
     (lista de contatos bloqueados)

◆➤ *𝑪𝑶𝑴𝑨𝑵𝑫𝑶 2*
  
 ◆➤ ${prefix}sticker
     (você tanbém pode marcar um foto )

◆➤ ${prefix}toimg
   (converte figurinha em imagem)
   
 ◆➤ ${prefix}tomp3
     (comando usado para baixar musica  )
     
 *◆ 𝐆𝐑𝐔𝐏𝐎𝐒*
 
 ◆➤ ${prefix}ownergroup
      (este comando mostra quem é o dono do grupo )
      
 ◆➤ ${prefix}linkgroup ou linkgp
      (com este comando o menbro comun pode pedir o link do grupo!. )
      
 ◆➤ ${prefix}closegp
      (so adm pode mandar mensagem)
      
 ◆➤ ${prefix}opengp
     ( todos podem mandar mensagem )
	 
     (REMOVER DO GRUPO)
 ◆➤ ${prefix}promote @USER
      (da a posição de ADM )
	  
 ◆➤ ${prefix}demote @user
     ( tira posição de ADM )
	 
 ◆➤ ${prefix}gay @user
 
 ◆➤ ${prefix}gado @user
  
 ◆➤ ${prefix}nivelgay
 
 ◆➤ ${prefix}nivelgado
 
 ◆+𝟭𝟴 HENTAI
 
 ◆➤ ${prefix}randomhentai ( nsfw ativo )
 
 ◆➤ ${prefix}hentai ( nsfw ativo )
 
 ◆➤ ${prefix}randomhentaio ( nsfw ativo )

◆ *𝐌𝐈́𝐃𝐈𝐀*

 ◆➤ ${prefix}randomk
 
 ◆➤ ${prefix}ytsearch

◆ *𝑫𝑶𝑾𝑵𝑳𝑶𝑨𝑫𝑺*
  
 ◆➤ ${prefix}images
 
 ◆➤ ${prefix}𝐲𝐭𝐦𝐩3 (desativado)
 
 ◆➤ ${prefix}ytmp4
 
 ◆➤ ${prefix}tiktok
 
 ◆➤ ${prefix}joox
 
◆ *som*
  
 ◆➤ ${prefix}play
 
 ◆➤ ${prefix}baixar
 
 ◆➤ ${prefix}tts
 
  ◆➤ ${prefix}lang (liguagem diponivel para ${prefix}tts lang texto
◆ *musica*
  
 ◆➤ ${prefix}lirik
 
 ◆➤ ${prefix}chord

◆ *vigiar*
  
 ◆➤ ${prefix}tiktokstalk
 
 ◆➤ ${prefix}igstalk
  
  *◆ 𝑨𝑵𝑰𝑴𝑬𝑺*
  
 ◆➤ ${prefix}animehug
 
 ◆➤ ${prefix}neonime
     
 ◆➤ ${prefix}loli
 
     (foto aleatoria de loli)
	 
 ◆➤ ${prefix}waifu
 
 ◆➤ ${prefix}randomanime
 
 ◆➤ ${prefix}wait
      ( comando usado par encontrar anime pela foto!. )
 
 ◆➤ ${prefix}nekonime
      (nekoanime)
      
◆ *Diverção*

 ◆➤ ${prefix}𝐬𝐢𝐦𝐢
 
  

 

  

`
}

exports.help = help
