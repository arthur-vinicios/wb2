const menuadmin = (prefix, pushname) => {
 return `*Menu disponivel apenas para ADM*\n
*_obs para o bot executar esses comandos e nescessario dar adm para o bot_* 

  *COMANDO DOS ADMINS*
 │
 🔰 ${prefix}opengp
 🔰 ${prefix}closegp
 🔰 ${prefix}promote
 🔰 ${prefix}demote
 🔰 ${prefix}tagall
 🔰 ${prefix}tagall2
 🔰 ${prefix}tagall3
 🔰 ${prefix}tagall4
 🔰 ${prefix}tagall5
 🔰 ${prefix}add (Bloqueado)
 🔰 ${prefix}albioban (Bloqueado)
 🔰 ${prefix}listadmins
 🔰 ${prefix}linkgroup
 🔰 ${prefix}welcome (não e possivel desativar depois de ativado)
 🔰 ${prefix}nsfw
 🔰 ${prefix}leveling
 🔰 ${prefix}level (leveling deve tar ativo)
 🔰 ${prefix}delete ou ${prefix}del
 🔰 ${prefix}simih
 🔰 ${prefix}ownergroup
 `


}

exports.menuadmin = menuadmin
